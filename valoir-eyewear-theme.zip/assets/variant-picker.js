/**
 * Valoir Variant Picker Component
 * Updates variant selection, pricing, media gallery thumbnail, and 3D color/finishes
 */
class ValoirVariantPicker extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('change', this.onVariantChange.bind(this));
  }

  onVariantChange(event) {
    this.selectedOptions = Array.from(this.querySelectorAll('input:checked, select'), el => el.value);
    this.currentVariant = this.getVariantData().find(variant => {
      return !variant.options.map((option, index) => {
        return this.selectedOptions[index] === option;
      }).includes(false);
    });

    if (this.currentVariant) {
      this.updatePrice();
      this.updateMasterId();
      this.updateMedia();
      this.update3DViewerFinish();
      this.publishVariantChange();
    }
  }

  getVariantData() {
    this.variantData = this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);
    return this.variantData;
  }

  updatePrice() {
    const priceBox = document.getElementById(`price-${this.dataset.section}`);
    if (priceBox && this.currentVariant) {
      const priceFormatted = (this.currentVariant.price / 100).toFixed(2);
      priceBox.textContent = `$${priceFormatted}`;
    }
  }

  updateMasterId() {
    const form = document.querySelector(`#product-form-${this.dataset.section}`);
    if (!form) return;
    const input = form.querySelector('input[name="id"]');
    if (input && this.currentVariant) {
      input.value = this.currentVariant.id;
    }
  }

  updateMedia() {
    if (!this.currentVariant || !this.currentVariant.featured_media) return;
    const gallery = document.querySelector('media-gallery');
    if (gallery && typeof gallery.setActiveMediaById === 'function') {
      gallery.setActiveMediaById(this.currentVariant.featured_media.id);
    }
  }

  update3DViewerFinish() {
    // Notify 3D viewer if frame color/acetate option changed
    const viewer = document.querySelector('valoir-3d-viewer');
    if (viewer && typeof viewer.updateMaterialColor === 'function') {
      const colorOption = this.selectedOptions[0]; // Usually first option is Color / Finish
      viewer.updateMaterialColor(colorOption);
    }
  }

  publishVariantChange() {
    this.dispatchEvent(new CustomEvent('variant:changed', {
      bubbles: true,
      detail: { variant: this.currentVariant }
    }));
  }
}

if (!customElements.get('variant-picker')) {
  customElements.define('variant-picker', ValoirVariantPicker);
}
