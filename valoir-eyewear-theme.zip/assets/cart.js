/**
 * Valoir Cart Controller
 * Native Shopify AJAX Cart API with Drawer & Free Shipping Indicator
 */
class ValoirCart {
  constructor() {
    this.cartDrawerBody = document.getElementById('cart-drawer-body');
    this.cartCountBadges = document.querySelectorAll('.cart-count-badge');
    this.initEventListeners();
    this.refresh();
  }

  initEventListeners() {
    // Intercept form submissions for Add to Bag
    document.addEventListener('submit', async (e) => {
      const form = e.target.closest('form[action*="/cart/add"]');
      if (!form) return;
      e.preventDefault();

      const submitBtn = form.querySelector('[type="submit"]');
      const originalText = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Adding...</span>';
      }

      try {
        const formData = new FormData(form);
        const res = await fetch(window.Valoir?.routes?.cart_add_url || '/cart/add.js', {
          method: 'POST',
          body: formData,
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await res.json();
        if (res.ok) {
          await this.refresh();
          window.valoirDrawerManager?.open('cart-drawer-container');
          window.ValoirA11y?.announce('Item successfully added to shopping bag');
        } else {
          const errorMsg = data.description || 'Error adding item to bag';
          window.ValoirA11y?.announce(errorMsg);
          let errorEl = form.querySelector('.cart-error-message');
          if (!errorEl) {
            errorEl = document.createElement('div');
            errorEl.className = 'cart-error-message';
            errorEl.style.cssText = 'color: #842029; background: #FDF2F2; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); font-size: 0.75rem; margin-top: 0.5rem;';
            form.appendChild(errorEl);
          }
          errorEl.textContent = errorMsg;
        }
      } catch (err) {
        console.error('Cart add error:', err);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
        }
      }
    });

    // Handle Quantity updates & removals in cart drawer
    if (this.cartDrawerBody) {
      this.cartDrawerBody.addEventListener('click', async (e) => {
        const changeBtn = e.target.closest('[data-cart-change]');
        if (changeBtn) {
          const key = changeBtn.getAttribute('data-cart-key');
          const qty = parseInt(changeBtn.getAttribute('data-cart-qty'), 10);
          await this.updateItem(key, qty);
        }
      });
    }
  }

  async refresh() {
    try {
      const res = await fetch('/cart.js', { headers: { 'Accept': 'application/json' } });
      if (!res.ok) return;
      const cart = await res.json();
      this.renderCart(cart);
    } catch (err) {
      console.warn('Could not fetch cart:', err);
    }
  }

  async updateItem(lineKey, quantity) {
    try {
      const res = await fetch(window.Valoir?.routes?.cart_change_url || '/cart/change.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ id: lineKey, quantity })
      });
      const cart = await res.json();
      this.renderCart(cart);
    } catch (err) {
      console.error('Cart update error:', err);
    }
  }

  renderCart(cart) {
    // Update count badges
    const totalCount = cart.item_count || 0;
    this.cartCountBadges.forEach(badge => {
      badge.textContent = totalCount;
      badge.style.display = totalCount > 0 ? 'flex' : 'none';
    });

    if (!this.cartDrawerBody) return;

    if (cart.items.length === 0) {
      const allUrl = window.Valoir?.routes?.all_products_collection_url || '/collections/all';
      this.cartDrawerBody.innerHTML = `
        <div style="text-align: center; padding: 3rem 1rem;">
          <p style="color: var(--color-text-muted); margin-bottom: 1.5rem;">${window.Valoir?.strings?.cartEmpty || 'Your bag is empty'}</p>
          <a href="${allUrl}" class="btn-primary" data-action="close-drawer">Explore Eyewear</a>
        </div>
      `;
      return;
    }

    const freeShippingThreshold = 25000; // in cents ($250)
    const progressPercent = Math.min(100, (cart.total_price / freeShippingThreshold) * 100);
    const amountLeft = ((freeShippingThreshold - cart.total_price) / 100).toFixed(2);

    let itemsHtml = cart.items.map(item => `
      <div class="cart-item">
        <img src="${item.image || ''}" alt="${item.title}" class="cart-item-image">
        <div class="cart-item-details">
          <h3 class="cart-item-title">${item.product_title}</h3>
          ${item.variant_title ? `<p style="font-size: 0.75rem; color: var(--color-text-muted);">${item.variant_title}</p>` : ''}
          <div class="cart-item-price">$${(item.final_price / 100).toFixed(2)}</div>
          <div class="cart-item-qty-row">
            <div class="qty-stepper">
              <button type="button" class="qty-btn" data-cart-change data-cart-key="${item.key}" data-cart-qty="${item.quantity - 1}">-</button>
              <span class="qty-input">${item.quantity}</span>
              <button type="button" class="qty-btn" data-cart-change data-cart-key="${item.key}" data-cart-qty="${item.quantity + 1}">+</button>
            </div>
            <button type="button" style="font-size: 0.75rem; color: var(--color-text-muted); text-decoration: underline;" data-cart-change data-cart-key="${item.key}" data-cart-qty="0">Remove</button>
          </div>
        </div>
      </div>
    `).join('');

    this.cartDrawerBody.innerHTML = `
      <div style="margin-bottom: 1rem;">
        <p style="font-size: 0.75rem; margin-bottom: 0.4rem;">
          ${progressPercent >= 100 
            ? '✓ You qualify for complimentary insured express courier.' 
            : `Add $${amountLeft} more for complimentary insured courier.`}
        </p>
        <div class="free-shipping-bar">
          <div class="free-shipping-progress" style="width: ${progressPercent}%;"></div>
        </div>
      </div>
      <div class="cart-items-list">${itemsHtml}</div>
      <div class="cart-drawer-footer">
        <div style="display: flex; justify-content: space-between; font-weight: 500;">
          <span>Subtotal</span>
          <span>$${(cart.total_price / 100).toFixed(2)}</span>
        </div>
        <p style="font-size: 0.6875rem; color: var(--color-text-muted);">Taxes and shipping calculated at checkout.</p>
        <a href="/checkout" class="btn-primary" style="width: 100%; text-align: center;">Proceed to Checkout</a>
      </div>
    `;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.valoirCart = new ValoirCart();
});
