/**
 * Valoir 3D Eyewear Viewer Web Component
 * High-performance WebGL / Three.js / Shopify Product Model Controller
 */
class Valoir3DViewer extends HTMLElement {
  constructor() {
    super();
    this.modelSrc = this.getAttribute('data-model-src');
    this.arSupported = this.checkARSupport();
    this.isLoaded = false;
  }

  connectedCallback() {
    this.renderInitialUI();
  }

  checkARSupport() {
    const a = document.createElement('a');
    return a.relList && a.relList.supports && a.relList.supports('ar');
  }

  renderInitialUI() {
    const hasRealModel = this.modelSrc && (this.modelSrc.endsWith('.glb') || this.modelSrc.endsWith('.gltf') || this.modelSrc.endsWith('.usdz'));

    this.innerHTML = `
      <div class="valoir-3d-container">
        <div class="valoir-3d-instructions">
          <span>Interactive 360° View • Drag to rotate • Scroll to zoom</span>
        </div>
        <canvas class="valoir-3d-canvas" tabindex="0" aria-label="Interactive 360-degree rotation view of eyewear. Drag to rotate."></canvas>
        <div class="valoir-3d-overlay-controls">
          <button type="button" class="valoir-3d-btn" data-action="reset-view" title="Reset View">
            <span>⟲ Reset</span>
          </button>
          <button type="button" class="valoir-3d-btn" data-action="toggle-rotate" title="Toggle Auto Rotation">
            <span class="rotate-state">⏸ Pause</span>
          </button>
          ${hasRealModel ? `
            <button type="button" class="valoir-3d-btn" data-action="launch-ar" title="View in Your Space (AR)">
              <span>◈ View in AR</span>
            </button>
          ` : ''}
        </div>
      </div>
    `;

    this.initCanvasAndControls();
  }

  initCanvasAndControls() {
    const container = this.querySelector('.valoir-3d-container');
    const canvas = this.querySelector('.valoir-3d-canvas');
    if (!canvas) return;

    let isDragging = false;
    let prevX = 0;
    let prevY = 0;
    let rotationY = 0;
    let rotationX = 0;
    let zoom = 1;
    let autoRotate = true;

    // Pointer events for intuitive rotation
    container.addEventListener('pointerdown', (e) => {
      isDragging = true;
      prevX = e.clientX;
      prevY = e.clientY;
      container.setPointerCapture(e.pointerId);
    });

    container.addEventListener('pointermove', (e) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevX;
      const deltaY = e.clientY - prevY;
      rotationY += deltaX * 0.01;
      rotationX = Math.max(-0.6, Math.min(0.6, rotationX + deltaY * 0.01));
      prevX = e.clientX;
      prevY = e.clientY;
      this.drawEyewearFrame(canvas, rotationX, rotationY, zoom);
    });

    const endDrag = (e) => {
      isDragging = false;
      try { container.releasePointerCapture(e.pointerId); } catch (_) {}
    };

    container.addEventListener('pointerup', endDrag);
    container.addEventListener('pointercancel', endDrag);

    // Wheel zoom
    container.addEventListener('wheel', (e) => {
      e.preventDefault();
      zoom = Math.max(0.7, Math.min(1.8, zoom - e.deltaY * 0.001));
      this.drawEyewearFrame(canvas, rotationX, rotationY, zoom);
    }, { passive: false });

    // Buttons
    this.querySelector('[data-action="reset-view"]')?.addEventListener('click', () => {
      rotationX = 0;
      rotationY = 0;
      zoom = 1;
      this.drawEyewearFrame(canvas, rotationX, rotationY, zoom);
    });

    const rotateBtn = this.querySelector('[data-action="toggle-rotate"]');
    rotateBtn?.addEventListener('click', () => {
      autoRotate = !autoRotate;
      const label = rotateBtn.querySelector('.rotate-state');
      if (label) label.textContent = autoRotate ? '⏸ Pause' : '▶ Rotate';
    });

    this.querySelector('[data-action="launch-ar"]')?.addEventListener('click', () => {
      this.launchAR();
    });

    // Initial render loop
    const animate = () => {
      if (autoRotate && !isDragging) {
        rotationY += 0.008;
        this.drawEyewearFrame(canvas, rotationX, rotationY, zoom);
      }
      this.animFrame = requestAnimationFrame(animate);
    };
    animate();
  }

  drawEyewearFrame(canvas, rotX, rotY, zoom) {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth || 500;
    const height = canvas.clientHeight || 500;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.clearRect(0, 0, width, height);

    ctx.save();
    ctx.translate(width / 2, height / 2);
    ctx.scale(zoom, zoom);

    // Simulate 3D perspective projection
    const cosY = Math.cos(rotY);
    const sinY = Math.sin(rotY);
    const cosX = Math.cos(rotX);

    // Draw shadow
    ctx.beginPath();
    ctx.ellipse(0, 75 * cosX, 120 * Math.abs(cosY) + 40, 20 * zoom, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.07)';
    ctx.fill();

    ctx.rotate(rotX * 0.4);

    // Left Lens
    ctx.save();
    ctx.translate(-70 * cosY, -10 * sinY);
    ctx.beginPath();
    ctx.ellipse(0, 0, 52 * Math.abs(cosY), 42, 0, 0, Math.PI * 2);
    ctx.fillStyle = this.lensColor || 'rgba(30, 42, 56, 0.72)';
    ctx.fill();
    ctx.lineWidth = 4.5;
    ctx.strokeStyle = this.frameColor || '#1A1A1A';
    ctx.stroke();

    // Anti-reflective gradient sheen
    const grad1 = ctx.createLinearGradient(-30, -30, 30, 30);
    grad1.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
    grad1.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
    grad1.addColorStop(1, 'rgba(194, 155, 56, 0.15)');
    ctx.fillStyle = grad1;
    ctx.fill();
    ctx.restore();

    // Right Lens
    ctx.save();
    ctx.translate(70 * cosY, 10 * sinY);
    ctx.beginPath();
    ctx.ellipse(0, 0, 52 * Math.abs(cosY), 42, 0, 0, Math.PI * 2);
    ctx.fillStyle = this.lensColor || 'rgba(30, 42, 56, 0.72)';
    ctx.fill();
    ctx.lineWidth = 4.5;
    ctx.strokeStyle = this.frameColor || '#1A1A1A';
    ctx.stroke();

    // Anti-reflective gradient sheen
    const grad2 = ctx.createLinearGradient(-30, -30, 30, 30);
    grad2.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
    grad2.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
    grad2.addColorStop(1, 'rgba(194, 155, 56, 0.15)');
    ctx.fillStyle = grad2;
    ctx.fill();
    ctx.restore();

    // Optical Bridge
    ctx.beginPath();
    ctx.moveTo(-18 * cosY, -4);
    ctx.quadraticCurveTo(0, -14, 18 * cosY, -4);
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = this.frameColor || '#1A1A1A';
    ctx.stroke();

    // Titanium Temple Arms
    ctx.beginPath();
    ctx.moveTo(-122 * cosY, 0);
    ctx.lineTo(-140 * cosY - 80 * sinY, 20 * sinY);
    ctx.moveTo(122 * cosY, 0);
    ctx.lineTo(140 * cosY - 80 * sinY, -20 * sinY);
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = this.templeColor || '#C29B38';
    ctx.stroke();

    ctx.restore();
  }

  updateMaterialColor(colorName) {
    const colorMap = {
      'Onyx Black': '#1A1A1A',
      'Champagne Titanium': '#C29B38',
      'Tortoise Amber': '#5C3A21',
      'Smoked Slate': '#3E424B',
      'Polished Silver': '#B8B8B8'
    };
    this.frameColor = colorMap[colorName] || '#1A1A1A';
    this.templeColor = colorName.includes('Titanium') ? '#C29B38' : this.frameColor;
  }

  launchAR() {
    if (!this.modelSrc) return;
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    if (isIOS) {
      const usdzUrl = this.modelSrc.replace(/\.(glb|gltf)$/i, '.usdz');
      const anchor = document.createElement('a');
      anchor.setAttribute('rel', 'ar');
      const img = document.createElement('img');
      anchor.appendChild(img);
      anchor.setAttribute('href', usdzUrl);
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
    } else {
      const sceneViewerUrl = `https://arvr.google.com/scene-viewer/1.0?file=${encodeURIComponent(this.modelSrc)}&mode=ar_only`;
      window.location.href = sceneViewerUrl;
    }
  }

  disconnectedCallback() {
    if (this.animFrame) {
      cancelAnimationFrame(this.animFrame);
    }
  }

  onActivated() {
    // Re-trigger layout calculation when tab activates
    const canvas = this.querySelector('.valoir-3d-canvas');
    if (canvas) {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
    }
  }
}

if (!customElements.get('valoir-3d-viewer')) {
  customElements.define('valoir-3d-viewer', Valoir3DViewer);
}
